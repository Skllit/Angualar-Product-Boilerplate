import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../../Interface/product';

@Component({
  selector: 'app-list',
  standalone: false,
  templateUrl: './list.component.html',
  styleUrl: './list.component.css'
})
export class ListComponent implements OnInit {
addNewProduct=false;
products$=new Observable<Product[]>

  constructor(){}

  ngOnInit(): void {

  }

  searchProducts(e:any){

  }

}
