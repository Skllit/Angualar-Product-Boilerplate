import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../Interface/product';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  api="http://localhost:3000"




}
